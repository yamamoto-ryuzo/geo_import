<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="fi_FI">
<context>
    <name>GeoImportDialogBase</name>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="35" />
        <source>dlg_base_title</source>
        <translation>Avoin Tieto (CKAN) Selain</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="57" />
        <source>dlg_base_search_term</source>
        <translation>Hakutermi:</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="102" />
        <source>dlg_base_btn_strt_srch</source>
        <translation>Haku</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="112" />
        <source>dlg_base_btn_show_all</source>
        <translation>Listaa kaikki saatavilla olevat tietojoukot</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="127" />
        <source>dlg_base_filter_to</source>
        <translation>Rajoita hakua luokalla:</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="266" />
        <source>dlg_base_btn_disclaimer</source>
        <translation>Vastuuvapauslauseke</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="299" />
        <source>dlg_base_srch_rslt</source>
        <translation>Tulokset:</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="316" />
        <source>IDC_lblPage</source>
        <translation />
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="340" />
        <source>dlg_base_btn_lt</source>
        <translation>&lt;</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="365" />
        <source>dlg_base_btn_gt</source>
        <translation>&gt;</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="389" />
        <source>dlg_base_descr</source>
        <translation>Kuvaus:</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="408" />
        <source>dlg_base_data_list</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Löydetyt tiedot:&lt;br /&gt;Valitse tietojoukko ladattavaksi.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="473" />
        <source>dlg_base_ressource</source>
        <translation>Resurssin URL:</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="585" />
        <source>dlg_base_btn_load_data</source>
        <translation>Lataa tiedot</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="592" />
        <source>dlg_base_btn_close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="90" />
        <source>dlg_base_ttip_search</source>
        <translation>Anna hakutermisi tähän.</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="109" />
        <source>dlg_base_ttip_show</source>
        <translation>Näytä kaikki CKAN palvelimessa saatavilla olevat tietojoukot</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="168" />
        <source>dlg_base_ttip_filter</source>
        <translation>Aktivoi valintaruut rajoittaaksesi hakua tähän luokkaan. Tuplaklikkaus luokkassa listaa kaikki sen tietojoukot.</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="337" />
        <source>dlg_base_ttip_prev</source>
        <translation>edellinen</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="362" />
        <source>dlg_base_ttip_next</source>
        <translation>seuraava</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="449" />
        <source>dlg_base_ttip_data_list</source>
        <translation>Lataa valitut tietojoukot ja yritä avata ne QGIS:ssä. Jos tietojoukkoja ei voida näyttää avataan hakemisto jossa ne ovat.</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="552" />
        <source>dlg_base_ttip_copy</source>
        <translation>Kopio leikepöydälle</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="514" />
        <source>dlg_base_ttip_resource</source>
        <translation>Valitun resurssin URL</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="517" />
        <source>?</source>
        <translation>?</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="259" />
        <source>dlg_base_btn_select_dataprovider</source>
        <translation>Valitse CKAN-palvelin</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="208" />
        <source>dlg_base_current_server</source>
        <translation>Nykyinen palvelin</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="230" />
        <source>dlg_base_lbl_cache_dir</source>
        <translation>Välimuistin hakemisto</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_base.ui" line="252" />
        <source>dlg_base_lbl_plugin_version</source>
        <translation>Lisäosan versio: {}</translation>
    </message>
</context>
<context>
    <name>GeoImportDialogDataProviders</name>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.ui" line="26" />
        <source>dlg_dataproviders_title</source>
        <translation>CKAN-palvelimet</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.ui" line="38" />
        <source>dlg_dataproviders_grp_manual</source>
        <translation>Lisää uusi CKAN-palvelin</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.ui" line="50" />
        <source>dlg_dataproviders_lbl_enter_dataprovider_url</source>
        <translation>CKAN API -päätepiste, esim: https://ckan0.cf.opendata.inter.prod-toronto.ca/api/3/</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.ui" line="63" />
        <source>dlg_dataproviders_btn_test_connection</source>
        <translation>Testaa yhteys</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.ui" line="70" />
        <source>dlg_dataproviders_btn_add_connection</source>
        <translation>Lisää CKAN-palvelin listaan</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.ui" line="96" />
        <source>dlg_dataproviders_lbl_search_for_provider</source>
        <translation>Etsi CKAN-palvelimia - lista: https://ckan.org/about/instances/</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.ui" line="106" />
        <source>dlg_dataproviders_lbl_nr_of_instances</source>
        <translation>{} / {} valittavissa (muilla ei ole API-osoitetta)</translation>
    </message>
</context>
<context>
    <name>GeoImportDialogSettings</name>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="26" />
        <source>dlg_set_title</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="90" />
        <source>dlg_set_cache_path</source>
        <translation>Välimuistin hakemisto:</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="125" />
        <source>dlg_set_ellipsis</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="248" />
        <source>dlg_set_btn_save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="255" />
        <source>dlg_set_btn_cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="65" />
        <source>dlg_set_tool_cache</source>
        <translation>Valitse hakemisto jonne ladattu tieto tallennetaan.</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="150" />
        <source>Authentication</source>
        <translation>Todennus</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="68" />
        <source>?</source>
        <translation>?</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="177" />
        <source>Clear</source>
        <translation>Tyhjennä</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="170" />
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="200" />
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-weight:600;"&gt;Warning: &lt;/span&gt;if this option is enabled, the same authentication configuration will be implicitely propagated to &lt;span style=" font-weight:600;"&gt;all&lt;/span&gt; OGC layers (WMS, WFS ...) returned by this catalog, this may leak credentials to the result endpoint  if it is not supposed to use the same authentication configuration.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-weight:600;"&gt;Varoitus: &lt;/span&gt;Jos tämä asetus on käytössä, sama todennusasetukset välittyvät automaattisesti kaikille tämän luettelon palauttamille OGC-tasoille (WMS, WFS ...). Tämä voi vuotaa tunnistetietoja kohdepisteeseen, jos sen ei ole tarkoitus käyttää samoja todennusasetuksia.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="203" />
        <source>Use the same authentication settings for all OGC layers</source>
        <translation>Käytä samoja todennusasetuksia kaikille OGC-tasoille</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="38" />
        <source>dlg_settings_grp_cache_folder</source>
        <translation>Välimuistikansio</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="144" />
        <source>dlg_settings_grp_authentication</source>
        <translation>Todennusasetukset</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="213" />
        <source>dlg_settings_grpbox_misc</source>
        <translation>Muut</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.ui" line="225" />
        <source>dlg_settings_chkbox_show_debug_info</source>
        <translation>Näytä virheilmoitukset 'Lokiviestit'-paneelissa</translation>
    </message>
</context>
<context>
    <name>GeoImportDialogDisclaimer</name>
    <message>
        <location filename="../ckan_browser_dialog_disclaimer.ui" line="32" />
        <source>dlg_dsc_dlg_title</source>
        <translation>Vastuuvapauslauseke</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_disclaimer.ui" line="70" />
        <source>dlg_dsc_title</source>
        <translation>CKAN Selain</translation>
    </message>
</context>
<context>
    <name>Util</name>
    <message>
        <location filename="../util.py" line="243" />
        <source>py_dlg_base_open_manager</source>
        <translation>Tuntematon tiedostotyyppi. &lt;br /&gt;&lt;br /&gt; Ladattu: &lt;br /&gt;{0} &lt;br /&gt;&lt;br /&gt; Avoin hakemisto?&lt;br /&gt;</translation>
    </message>
</context>
<context>
    <name>self.util</name>
    <message>
        <location filename="../ckan_browser_dialog.py" line="70" />
        <source>py_dlg_base_page_1_1</source>
        <translation>Sivu 1/1</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="201" />
        <source>py_dlg_base_search_result_0</source>
        <translation>Hakutulokset: 0</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="202" />
        <source>py_dlg_base_no_result</source>
        <translation>Ei tuloksia</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="211" />
        <source>py_dlg_base_result_count</source>
        <translation>Hakutulos: {0} Datasets</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="213" />
        <source>py_dlg_base_page_count</source>
        <translation>Sivu {0}/{1:.0f}</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="283" />
        <source>py_dlg_base_warn_no_resource</source>
        <translation>Resursseja ei valittu</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="298" />
        <source>py_dlg_base_warn_cache_dir_not_created</source>
        <translation>Välimuistin hakemistoa ei voida luoda: {0}</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="331" />
        <source>py_dlg_base_data_already_loaded</source>
        <translation>Tietojoukko on jo ladattu. Lataatko uudelleen?</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="345" />
        <source>py_dlg_base_big_file</source>
        <translation>Tiedoston koko on {0} MB. Lataa siitä huolimatta?</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="380" />
        <source>py_dlg_base_warn_not_extracted</source>
        <translation>Arkistoa ei voida purkaa:&lt;br /&gt;{0}</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="389" />
        <source>py_dlg_base_open_manager</source>
        <translation>Tuntematon tiedostotyyppi. &lt;br /&gt;&lt;br /&gt; Ladattu: &lt;br /&gt;{0} &lt;br /&gt;&lt;br /&gt; Avoin hakemisto?&lt;br /&gt;</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="392" />
        <source>py_dlg_base_lyr_not_loaded</source>
        <translation>Tasoa ei voida ladata:&lt;br /&gt;{0}&lt;br /&gt;{1}</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="441" />
        <source>dlg_base_ttip_search</source>
        <translation>Anna hakutermisi tähän.</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="444" />
        <source>dlg_base_ttip_filter</source>
        <translation>Aktivoi valintaruut rajoittaaksesi hakua tähän luokkaan. Tuplaklikkaus luokkassa listaa kaikki sen tietojoukot.</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="447" />
        <source>dlg_base_ttip_data_list</source>
        <translation>Lataa valitut tietojoukot ja yritä avata ne QGIS:ssä. Jos tietojoukkoja ei voida näyttää avataan hakemisto jossa ne ovat.</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="450" />
        <source>dlg_base_ttip_resource</source>
        <translation>Valitun resurssin URL</translation>
    </message>
    <message>
        <location filename="../ckanconnector.py" line="150" />
        <source>cc_url_error</source>
        <translation>Virhe saataessa URL&lt;br /&gt; {0} &lt;br /&gt;&lt;br /&gt;{1}</translation>
    </message>
    <message>
        <location filename="../ckanconnector.py" line="368" />
        <source>cc_connection_timeout</source>
        <translation>Yhteyden aikakatkaisu:&lt;br /&gt;&lt;br /&gt;{0}</translation>
    </message>
    <message>
        <location filename="../ckanconnector.py" line="332" />
        <source>cc_download_error</source>
        <translation>Latausvirhe: {0}</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.py" line="119" />
        <source>cc_api_not_accessible</source>
        <translation>CKAN API ei ole käytettävissä</translation>
    </message>
    <message>
        <location filename="../ckanconnector.py" line="381" />
        <source>cc_server_fault</source>
        <translation>Palvelinvirhe</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.py" line="123" />
        <source>cc_invalid_json</source>
        <translation>Palvelimen vastaus ei ole oikeanlainen JSON objekti</translation>
    </message>
    <message>
        <location filename="../ckanconnector.py" line="415" />
        <source>cc_wrong_api</source>
        <translation>Ainoastaan v3 on tuettu</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_disclaimer.py" line="56" />
        <source>py_disc_info_html</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd"&gt;&lt;html&gt;&lt;head&gt;&lt;meta name="qrichtext" content="1" /&gt;&lt;style type="text/css"&gt;p, li { white-space: pre-wrap; }&lt;/style&gt;&lt;/head&gt;&lt;body style=" font-family:'.Helvetica Neue DeskInterface'; font-size:13pt; font-weight:400; font-style:normal;"&gt;&lt;h1&gt;Disclaimer&lt;/h1&gt;&lt;p&gt;EN Es besteht die Möglichkeit, dass das Plugin nicht mit allen CKAN funktioniert, da die Metadaten der Plattformen unterschiedlich abgebildet werden. Unterstützt werden nur Server, die groups oder tags verwenden. &lt;a href="http://docs.ckan.org/en/latest/api/"&gt;link auf CKAN docs&lt;/a&gt;&lt;br /&gt;Dieses Plugin funktioniert nur mit API-Verson 3&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.py" line="222" />
        <source>py_dlg_set_info_conn_succs</source>
        <translation>Yhteys onnistui</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.py" line="94" />
        <source>py_dlg_set_warn_cache_not_use</source>
        <translation>Välimuistin hakemistoa ei voida käyttää</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.py" line="110" />
        <source>dlg_set_tool_cache</source>
        <translation>Valitse hakemisto jonne ladattu tieto tallennetaan.</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_settings.py" line="117" />
        <source>Select Authentication</source>
        <translation>Valitse todennus</translation>
    </message>
    <message>
        <location filename="../ckan_browser.py" line="194" />
        <source>&amp;Catalog Integration</source>
        <translation>&amp;Avoin Data (CKAN) Selain</translation>
    </message>
    <message>
        <location filename="../ckan_browser.py" line="175" />
        <source>Catalog Integration</source>
        <translation>Avoin Data (CKAN) Selain</translation>
    </message>
    <message>
        <location filename="../ckan_browser.py" line="184" />
        <source>ckan_browser_settings</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="96" />
        <source>py_dlg_base_current_server</source>
        <translation>py_dlg_base_current_server</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog.py" line="97" />
        <source>py_dlg_base_cache_path</source>
        <translation>py_dlg_base_cache_path</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.py" line="297" />
        <source>py_dlg_data_providers_no_server_selected</source>
        <translation>py_dlg_data_providers_no_server_selected</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.py" line="166" />
        <source>py_dlg_data_providers_cannot_delete_sever_from_official_list</source>
        <translation>py_dlg_data_providers_cannot_delete_sever_from_official_list</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.py" line="237" />
        <source>py_dlg_data_providers_custom_server</source>
        <translation>py_dlg_data_providers_custom_server</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.py" line="237" />
        <source>py_dlg_data_providers_name_custom_server</source>
        <translation>py_dlg_data_providers_name_custom_server</translation>
    </message>
    <message>
        <location filename="../ckan_browser_dialog_dataproviders.py" line="249" />
        <source>py_dlg_data_providers_custom_server_name_exists</source>
        <translation>py_dlg_data_providers_custom_server_name_exists</translation>
    </message>
</context>
</TS>